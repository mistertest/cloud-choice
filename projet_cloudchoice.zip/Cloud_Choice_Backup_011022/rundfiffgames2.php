<?php


/* Diff Gfn All days eccept Mercredi */
// https://console.cron-job.org/jobs
// Diff Json GFN all Days eccept Wednesday - 17H

# Get new games gfn
$output1 = shell_exec("json-diff --sort --raw-json /var/www/html/gfnBefore.json /var/www/html/gfnSoup.json > /var/www/html/gfnDiff1.json");


/*message confirmation scrapping ok*/

echo "<b> Diff Gfn All days eccept Mercredi </b>";


?>