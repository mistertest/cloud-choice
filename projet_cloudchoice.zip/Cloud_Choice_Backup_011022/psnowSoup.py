#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re
import time
import html5lib



# SCRAPING PSNOW OK
##################################


# Headless Chrome and Selenium 

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.support import expected_conditions as EC


chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)

soup = BeautifulSoup(driver.page_source,'html.parser')


# Get The URL to Scrape
driver.get('https://psnowguide.com/games/')




my_data = []



while True:
    for div in driver.find_elements_by_css_selector('div.type-movie div.movie__info--head'):
        title = div.find_element_by_css_selector('a h3').text
        print(title)
        my_data.append({"title":title })

    try:
        buttonNext = driver.find_element_by_css_selector('nav.masvideos-pagination  a.next.page-numbers')
        driver.execute_script("arguments[0].click();", buttonNext)
    except:
        break 

        

        driver.close()



# CREATE AND EXPORT TO JSON

with open('psnowSoup.json', 'w') as outfile:
     json.dump(my_data, outfile)


     print('PSNOW JSON OK')


# END SCRAPING
####################





