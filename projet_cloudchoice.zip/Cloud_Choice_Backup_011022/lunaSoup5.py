#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json
import time
from time import sleep



# SCRAPING LUNA LIST GAMES - UBISOFT CHANNEL
#############################################



# Headless Chrome and Selenium 

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)



# Get Url Games list Ubisoft Channel
driver.get('https://www.amazon.com/luna/channel/B08LYSYW3H')
# Confirmation get url
print('LUNA GAME LIST OK')



# Imperative time sleep for working
time.sleep(8) 




# SCRAPING START
#################################


my_data = []
my_dataError = [{"title": "error", "store": "error" }]

# Introduction beautifulsoup
soup=BeautifulSoup(driver.page_source,'html.parser')
# print(soup.prettify())

# get global items list
items = soup.select('div.impression._gmrcde div._zxc7gz')


# Code error no data  
if soup.find_all("img", {"class": "_ge4rm6"}):
    print("class Found ok") 
else:
    print("Error not Found class")
    with open('lunaSoup5.json', 'w') as outfile:
        json.dump(my_dataError, outfile)
        print('LUNA5 JSON OK')


for itemGame in items:
    
    # get title game word
    # title = itemGame.select('img.game-name.highlight-green')[0].get_text()

    title = itemGame.select("img._ge4rm6")[0]["alt"]
    title = title.replace('®','').replace('™','').replace(':','')




    # itemTitle = itemGame.select("img._ctz3yu")
    # if len(itemTitle) == 0 :
    #      title = "N/A"
    # else:
    #      title = itemGame.select("img._ctz3yu")[0]["alt"]


    # remove copyright in title
    # title = title.replace('®','').replace('™','')


    # Create Store key and Extract Word between parenthese in title for value
    # store = title[title.find('(')+1:title.find(')')]
    
    # Remove word between parenthes in title after create store
    # title = re.sub(r"\([^()]*\)","", title)

    # remove last space in title - lstrip for first space
    # title = title.rstrip()

    # title = unidecode.unidecode(title)


    store = "Ubisoft+ Channel"





# Insert data in array
    my_data.append({"title": title, "store": store })




# SCRAPING END
#################################


# PRINT TEST IN TERMINAL

# pprint(my_data)


# CREATE AND EXPORT TO JSON
#################################


with open('lunaSoup5.json', 'w') as outfile:
    json.dump(my_data, outfile)

    print('LUNA5 JSON OK')




driver.close()