<?php


/* Scrapping Luna3 */



# get json Luna
 $output1 = shell_exec("python3 /var/www/html/lunaSoup3.py");





/*message confirmation scrapping ok*/

echo "<b> Scrapping Luna3 - OK</b>";


?>