<?php


/* get json GFN Mercredi 23h */
// https://console.cron-job.org/jobs
// Scraping GFN - gfnBefore Mercredi - 23H


# get json GFN
$output1 = shell_exec("python3 /var/www/html/gfnBefore.py");



/*message confirmation scrapping ok*/

echo "<b> get json GFN Mercredi 23h - OK </b>";


?>