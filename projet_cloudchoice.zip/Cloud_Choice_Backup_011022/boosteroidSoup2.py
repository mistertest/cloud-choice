#!/usr/bin/python3
# -*- coding: utf-8 -*-

# IMPORTS - ALL BEAUTIFUL SOUP / SELENIUM / JSON
######################################################

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re




from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import time
from time import sleep
from selenium.common.exceptions import NoSuchElementException

# SELENIUM + CHROME HEADLESS DRIVER
###################################################################

chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)






# SIGN IN BOOSTEROID
############################


url="https://cloud.boosteroid.com/auth/login/"

driver.get(url)

time.sleep(5) 
username = driver.find_element(By.ID, "authLoginEmailField")
username.send_keys("hcrea@live.fr")


time.sleep(5) 
password = driver.find_element(By.ID, "authLoginPasswordField")
password.send_keys("******")

time.sleep(5) 
sign_in_button = driver.find_element(By.CLASS_NAME, "primary-button")

sign_in_button.click()

print('LOGIN BOOSTEROID OK')


time.sleep(6) 

# getting the button by class name
button = driver.find_element_by_xpath("/html/body/app-root/app-main/main/app-dashboard/div/app-library/div/div[1]/app-library-filters/form/div[1]/div[3]/app-tab-button/button")
 
# Clicking on the button
button.click()
time.sleep(6) 


print('BUTTON CLICK INSTALL OK')

time.sleep(5)




# SROLL TO BOTTOM PAGE START
############################

scroll_pause_time = 1 # You can set your own pause time. My laptop is a bit slow so I use 1 sec
screen_height = driver.execute_script("return window.screen.height;")   # get the screen height of the web
i = 1

while True:
    # scroll one screen height each time
    driver.execute_script("window.scrollTo(0, {screen_height}*{i});".format(screen_height=screen_height, i=i))  
    i += 1
    time.sleep(scroll_pause_time)
    # update scroll height each time after scrolled, as the scroll height can change after we scrolled the page
    scroll_height = driver.execute_script("return document.body.scrollHeight;")  
    # Break the loop when the height we need to scroll to is larger than the total scroll height
    if (screen_height) * i > scroll_height:
        break

# SROLL TO BOTTOM PAGE END
############################

print('SROLL TO BOTTOM PAGE END OK')


# SCRAPING START
############################

print('SCRAPING START')


# Initaitlize the array data
my_data = []
my_dataError = [{"title": "error", "store": "error" }]


# Introduction beautifulSoup
soup = BeautifulSoup(driver.page_source, "html.parser")
# print(soup.prettify())


# Code error no data  
if soup.find_all("div", {"class": "item-game-in__content"}):
    print("class Found ok") 
else:
    print("Error not Found class")
    with open('boosteroidSoup2.json', 'w') as outfile:
        json.dump(my_dataError, outfile)
        print('BOOSTEROID2 JSON WARNING ERROR OK')
        time.sleep(5)


# Test first loop
# for img in soup.select('div.library__wrapper.ng-star-inserted img.store-item__image'):
# print(p.get_text(strip=True, separator='\n'))
# print('-' * 80)


# Get Items loop of games - Title and Store
for item in soup.select("div.library__wrapper div.store-item"):

    title = item.select("div.item-game-in__content h4")[0].get_text()
    title = title.replace('®','').replace('™','').replace(':','')
    # Remove word between parenthes in title after create store
    title = re.sub(r"\([^()]*\)","", title)

    # remove last space in title - lstrip for first space
    title = title.rstrip()
    store = item.select('div.store-item__platform img.store-item__platform-icon')[0]['alt'] 
    store = store.replace('Epic Games Store','Epic').replace('Rockstar Games','Rockstar')
    
    # div.store-item__platform img.store-item__platform-icon
    # store = item.select('img.store-item__platform-icon')[0]['alt']
    # print(item.select('img.store-item__platform-icon'))




# IF ITEM NOT CONTAIN THE ICON STORE - REPLACE VALUE


    # itemStore = item.select('img.store-item__platform-icon')
    # if len(itemStore) == 0 :
    #     store = "N/A"
    # else:
    #     store = item.select('img.store-item__platform-icon')[0]['alt']



# Code error no data  
    if not title:
        title = "Error_Boosteroid_data"
        store = "Error_Boosteroid_data"


    

# GET ARRAY WITH DATA     
    my_data.append({"title": title,  "store": store })

# Test Array in terminal


    # pprint(my_data)
    

# CREATE AND EXPORT DATA TO JSON


with open('boosteroidSoup2.json', 'w') as outfile:
    json.dump(my_data, outfile)

    print('BOOSTEROID2 JSON OK')







# SCRAPING END
############################





driver.close()