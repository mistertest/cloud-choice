<?php


/* Scrapping Luna6 */



# get json Luna
 $output1 = shell_exec("python3 /var/www/html/lunaSoup6.py");





/*message confirmation scrapping ok*/

echo "<b> Scrapping Luna6 - OK</b>";


?>