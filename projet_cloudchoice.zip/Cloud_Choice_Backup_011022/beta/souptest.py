#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode


# LINK LUNA TEST
# https://www.amazon.com/luna/channel/B092YQCGP2


# TEST OK 1

# url = 'https://notes.ayushsharma.in/technology'
# data = requests.get(url)

# my_data = []

# html = BeautifulSoup(data.text, 'html.parser')
# articles = html.select('a.post-card')

# for article in articles:

#     title = article.select('.card-title')[0].get_text()
#     excerpt = article.select('.card-text')[0].get_text()
#     pub_date = article.select('.card-footer small')[0].get_text()

#     my_data.append({"title": title, "excerpt": excerpt, "pub_date": pub_date})

# pprint(my_data)



# TEST OK 2

# url = 'https://www.encodeproject.org/search/?type=Experiment&control_type!=*&status=released&perturbed=false&assay_title=TF+ChIP-seq&assay_title=Histone+ChIP-seq&replicates.library.biosample.donor.organism.scientific_name=Homo+sapiens&biosample_ontology.term_name=K562&biosample_ontology.term_name=HEK293&biosample_ontology.term_name=MCF-7&biosample_ontology.term_name=HepG2&limit=all'

# response = requests.get(url)
# soup = BeautifulSoup(response.text, "html.parser")
# a_tags = soup.select('a[aria-label]')
# for tag in a_tags:
#     print(tag.text.strip())


# HEADERS = ({'User-Agent':
#             'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
#             'Accept-Language': 'en-US, en;q=0.5'})

# URL = "https://www.amazon.com/luna/channel/B092YQCGP2"
# webpage = requests.get(URL, headers=HEADERS)



# soup = BeautifulSoup(webpage.content, "lxml")
# images = soup.findAll('img._ctz3yu')
# for image in images:
#     #print image source
#     pprint(image['src'])
#     #print alternate text
#     pprint(image['alt'])




# URL = 'https://www.amazon.com/luna/channel/B092YQCGP2'

# headers = {"User-Agent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36'}

# page = requests.get(URL, headers=headers)

# soup = BeautifulSoup(page.content, 'lxml')

# images = soup.findAll(class_="_ctz3yu")
# for image in images:
#     #print image source
#     pprint(image['src'])
#     #print alternate text
#     pprint(image['alt'])




# url = ' https://www.nvidia.com/fr-fr/geforce-now/games'
# data = requests.get(url)

# my_data = []

# html = BeautifulSoup(data.text, 'html.parser')
# articles = html.select('div.main-div-block div.div-game-name')

# for article in articles:

#     title = article.select('span.game-name.highlight-green').get_text()
 

#     my_data.append({"title": title})

# pprint(my_data)






# SRAPING GFN LIST GAMES OK
##################################



# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
# chrome_options = Options()
# chrome_options.add_argument("--headless")
# chrome_options.add_argument('--no-sandbox')
# # driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
# driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)


# driver.get('https://www.nvidia.com/fr-fr/geforce-now/games')
# print('test ok')



# my_data = []

# soup=BeautifulSoup(driver.page_source,'html.parser')
# # print(soup.prettify())


# articles = soup.select('div.div-game-name')

# for article in articles:

#     title = article.select('span.game-name.highlight-green')[0].get_text()
  

#     my_data.append({"title": title })

# # pprint(my_data)


# with open('mytest.json', 'w') as outfile:
#     json.dump(my_data, outfile)

# driver.close()





# SCRAPING PSNOW OK
##################################


# Headless Chrome and Selenium 

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)


# Get The URL to Scrape
driver.get('https://www.playstation.com/fr-fr/ps-now/ps-now-games')


# Confirmation get url
print('SITE PSNOW OK')



# SCRAPING START

my_data = []

# Introduction Beautiful Script
soup=BeautifulSoup(driver.page_source,'html.parser')
# print(soup.prettify())

# Loop Item div
for p in soup.select('div.tabbed-component div.content-grid div.box p'):
    # print(p.get_text(strip=True, separator='\n'))
    # print('-' * 80)


# Get title of games
    title =  p.get_text(strip=True)
    # Method replace
    # replace(u'\xa0', u' ')
    # Use method unidecode or replace for Unicode Characters
    title = unidecode.unidecode(title)
    # Delete Coyright
    title = title.replace( '*','')

    itemGame = title
    if len(itemGame) == 0 :
        title = "N/A"
    else:
        title



    if  ( (title == "A") or (title == "B") or (title == "C") or (title == "D") or (title == "E") or (title == "F") 
    or (title == "G") or (title == "H") or (title == "I") or (title == "J") or (title == "K") or (title == "L") 
    or (title == "M") or (title == "N") or (title == "O") or (title == "P") or (title == "Q") or (title == "R") 
    or (title == "S") or (title == "T") or (title == "U") or (title == "V") or (title == "W") or (title == "X")
    or (title == "Y") or (title == "Z") or (title == "0-9")) :
       title = "N/A"




    my_data.append({"title":title })



# Print in Terminal   

    pprint(my_data)



# CREATE AND EXPORT TO JSON

# with open('mytest2.json', 'w') as outfile:
#      json.dump(my_data, outfile)




# END SCRAPING
####################





driver.close()