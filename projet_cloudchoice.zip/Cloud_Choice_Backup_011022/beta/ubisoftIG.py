#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re
import time
import html5lib


# TUTOS
# https://stackoverflow.com/questions/71630977/selenium-use-pagination-on-site
# https://stackoverflow.com/questions/55051305/unable-to-scrape-the-next-pagepagination-using-python-selenium
# https://subscription.packtpub.com/video/data/9781801818483/p7/video7_9/pagination-and-extracting-data
# https://subscription.packtpub.com/video/data/9781801818483/p7/video7_10/exception-handling-for-unavailable-elements
# https://stackoverflow.com/questions/71480545/how-to-stop-the-selenium-webdriver-after-reaching-the-last-page-while-scraping-t
# https://stackoverflow.com/questions/44514090/python-with-selenium-pagination-issue
# https://stackoverflow.com/questions/11223011/attributeerror-list-object-has-no-attribute-click-selenium-webdriver
# https://stackoverflow.com/questions/65057975/attributeerror-list-object-has-no-attribute-click-error-clicking-on-an-elem
# https://stackoverflow.com/questions/42216174/selecting-a-button-list-object-has-no-attribute-click-python-selenium
# https://stackoverflow.com/questions/59251187/how-to-paginate-in-selenium-python
# https://www.freecodecamp.org/news/how-to-scrape-websites-with-python-2/
# https://stackoverflow.com/questions/68120084/python-selenium-loading-next-pages-url-but-would-always-first-load-the-first
# https://stackoverflow.com/questions/37198717/if-statement-element-click-or-break-not-working

# DEMO SITE TO SCRAPE
# https://quotes.toscrape.com/

# IntantGaming Test
# https://www.instant-gaming.com/fr/rechercher/?type%5B0%5D=steam&type%5B1%5D=steam&platform%5B0%5D=&sort_by=&min_reviewsavg=10&max_reviewsavg=100&noreviews=1&min_price=0&max_price=100&noprice=1&gametype=games&available_in=FR&query=&page=94

# UBISOFT IG
##################################




# Headless Chrome and Selenium 

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.support import expected_conditions as EC


chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)

soup = BeautifulSoup(driver.page_source,'html.parser')



# The link included filter with STOCK and GAMES ONLY
driver.get("https://www.instant-gaming.com/fr/rechercher/?platform%5B0%5D=1&type%5B0%5D=ubisoft+connect&sort_by=&min_reviewsavg=10&max_reviewsavg=100&noreviews=1&min_price=0&max_price=100&noprice=1&instock=1&gametype=games&available_in=FR&query=&page=1")

my_data = []


while True:
    for div in driver.find_elements_by_css_selector('div.item.force-badge'):
        # check if element exist in the loop - if not replace by value and continue the scrap
        try:
            div.find_element_by_css_selector('div.discount')
            discountIG_Ubi = div.find_element_by_css_selector('div.discount').text
            # print(discountIG)
        except NoSuchElementException:
            discountIG_Ubi = "N/A"
            # print(discountIG)
            continue

        print(div.find_element_by_css_selector('div.fallback').text)
        print(div.find_element_by_css_selector('div.price').text)
        print(div.find_element_by_css_selector('div.discount').text)
        print(driver.find_element_by_css_selector('ul.pagination li.selected').text)

        title = div.find_element_by_css_selector('div.fallback').text
        titleIG_Ubi = div.find_element_by_css_selector('div.fallback').text        
        priceIG_Ubi = div.find_element_by_css_selector('div.price').text
        urlIG_Ubi = div.find_element_by_css_selector('a.cover.video').get_attribute('href')
        pageIG_Ubi = driver.find_element_by_css_selector('ul.pagination li.selected').text
        imgCoverIG_Ubi = driver.find_element_by_css_selector("img.picture").get_attribute("src")
        launcherIG_Ubi = "Ubisoft"

        # Insert data in array
        my_data.append({"title": title, "titleIG_Ubi": titleIG_Ubi, "priceIG_Ubi" : priceIG_Ubi, "discountIG_Ubi": discountIG_Ubi, "urlIG_Ubi": urlIG_Ubi, "launcherIG_Ubi" : launcherIG_Ubi, "imgCoverIG": imgCoverIG_Ubi, "pageIG_Ubi": pageIG_Ubi })

    # Global while try - Check if arrow next exist and is not prev - if not exist this is the last page break the scrap
    try:
        driver.find_element_by_css_selector('ul.pagination a.arrow div.icon-arrow:not(ul.pagination a.arrow.left div.icon-arrow)').click()
    except:
        break


# Export Json
with open('ubisoftIG.json', 'w') as outfile:
    json.dump(my_data, outfile)
    print('UBISOFT IG JSON OK')


driver.close()






