#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re





# SRAPING GFN BETA LIST GAMES OK
##################################




# Headless Chrome and Selenium 

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)


# Get Url Games list GeForce Now
driver.get('https://www.nvidia.com/fr-fr/geforce-now/games')
# Confirmation get url
print('GFN BETA GAME LIST OK')



# SCRAPING START
#################################


my_data = []
my_dataError = [{"title": "error", "store": "error" }]

# Introduction beautifulsoup
soup=BeautifulSoup(driver.page_source,'html.parser')
# print(soup.prettify())

# get global items list
items = soup.select('div.div-game-name')


# Code error no data  
if soup.find_all("span", {"class": "game-name highlight-green"}):
    print("class Found ok") 
else:
    print("Error not Found class")
    with open('gfnSoup.json', 'w') as outfile:
        json.dump(my_dataError, outfile)
        print('GFN JSON WARNING ERROR OK')




for itemGame in items:
    
    # get title game word
    title = itemGame.select('span.game-name.highlight-green')[0].get_text()

    # remove copyright in title
    # title = title.replace('®','').replace('™','').replace(':','')

    # Create Store key and Extract Word between parenthese in title for value
    store = title[title.find('(')+1:title.find(')')]
    store = store.replace('Epic Games Store','Epic').replace('GOG.COM','gog').replace('Ubisoft Connect','Ubisoft')
    
    # Remove word between parenthes in title after create store
    title = re.sub(r"\([^()]*\)","", title)

    # remove last space in title - lstrip for first space
    title = title.rstrip()

    title = unidecode.unidecode(title)





  


# Insert data in array
    my_data.append({"title": title, "store": store })





# SCRAPING END
#################################


# PRINT TEST IN TERMINAL

# pprint(my_data)


# CREATE AND EXPORT TO JSON
#################################


with open('gfnBeta.json', 'w') as outfile:
    json.dump(my_data, outfile)

    print('GFN BETA JSON OK')




driver.close()