#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re
import time




# SRAPING XCLOUD LIST GAMES OK
##################################




# Headless Chrome and Selenium 


# from selenium import webdriver
# path = './drivers/geckodriver.exe'
# driver = webdriver.Firefox(executable_path = path)

# from selenium.webdriver.chrome.options import Options
# chrome_options = Options()
# chrome_options.add_argument("--headless")
# chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
# driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)


from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import time
from time import sleep
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys

chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)









# Get Url Games list Xcloud
driver.get('https://www.xbox.com/fr-FR/play/gallery/all-games')
# Confirmation get url
print('XCLOUD GAME LIST OK')

# SCRAPING START
#################################

my_data = []

def getItems(items):
    for itemGame in items:
        
        # get title game word
        title = itemGame.select('div.Details-module__title___2aeZq')[0].get_text()
        # developer = itemGame.select('div.GameItem-module__xdsGameItemSubtitle___4nPvi')[0].get_text()
        
        # remove copyright in title
        title = title.replace('®','').replace('™','').replace(':','')

        
        # Remove word between parenthes in title after create store
        title = re.sub(r"\([^()]*\)","", title)

        # remove last space in title - lstrip for first space
        title = title.rstrip()

        title = unidecode.unidecode(title)

        print(title)


        if ({"title":title} not in my_data):
            my_data.append({"title": title })



initialValue = 0
nextValue = driver.execute_script("return window.innerHeight")

reached_end = False
height = driver.execute_script("return document.body.scrollHeight")

# height = 100000

while not reached_end:

    # Introduction beautifulsoup
    soup = BeautifulSoup(driver.page_source,'html.parser')
    # print(soup.prettify())

    # get global items list
    myItems = soup.select('a.BaseItem-module__container___3oypI')

    getItems(myItems)

    print(initialValue, nextValue, height)

    # Scroll down to bottom
    driver.execute_script("window.scrollTo("+str(initialValue)+", "+str(nextValue)+");")

    # Wait to load page
    time.sleep(5)

    initialValue=nextValue
    nextValue+=600

    if initialValue > height:
        reached_end = True


# SCRAPING END
#################################

# PRINT TEST IN TERMINAL

# pprint(my_data)


# CREATE AND EXPORT TO JSON
#################################


with open('xcloudSoupdebug.json', 'w') as outfile:
    json.dump(my_data, outfile)

    print('XCLOUD JSON OK')




driver.close()
