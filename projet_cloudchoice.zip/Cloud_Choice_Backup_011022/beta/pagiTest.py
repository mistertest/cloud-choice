#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re
import time
import html5lib


# TUTOS
# https://stackoverflow.com/questions/71630977/selenium-use-pagination-on-site
# https://stackoverflow.com/questions/55051305/unable-to-scrape-the-next-pagepagination-using-python-selenium
# https://subscription.packtpub.com/video/data/9781801818483/p7/video7_9/pagination-and-extracting-data
# https://subscription.packtpub.com/video/data/9781801818483/p7/video7_10/exception-handling-for-unavailable-elements
# https://stackoverflow.com/questions/71480545/how-to-stop-the-selenium-webdriver-after-reaching-the-last-page-while-scraping-t
# https://stackoverflow.com/questions/44514090/python-with-selenium-pagination-issue
# https://stackoverflow.com/questions/11223011/attributeerror-list-object-has-no-attribute-click-selenium-webdriver
# https://stackoverflow.com/questions/65057975/attributeerror-list-object-has-no-attribute-click-error-clicking-on-an-elem
# https://stackoverflow.com/questions/42216174/selecting-a-button-list-object-has-no-attribute-click-python-selenium
# https://stackoverflow.com/questions/59251187/how-to-paginate-in-selenium-python
# https://www.freecodecamp.org/news/how-to-scrape-websites-with-python-2/
# https://stackoverflow.com/questions/68120084/python-selenium-loading-next-pages-url-but-would-always-first-load-the-first
# https://stackoverflow.com/questions/37198717/if-statement-element-click-or-break-not-working

# DEMO SITE TO SCRAPE
# https://quotes.toscrape.com/



# SRAPING DEMO PAGINATION
##################################




# Headless Chrome and Selenium 

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait 
from selenium.webdriver.support import expected_conditions as EC


chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)

soup = BeautifulSoup(driver.page_source,'html.parser')




# SCRAPING SITE TOSCRAPE DEMO


driver.get("https://quotes.toscrape.com/")



while True:
    for div in driver.find_elements_by_css_selector('.quote'):
        print(div.find_element_by_css_selector('.text').text)
        print(div.find_element_by_css_selector('.author').text)

    try:
        driver.find_element_by_css_selector('.next a').click()
    except:
        break



#  Export To Json
#  with open('igSoupV3.json', 'w') as outfile:
#  json.dump(my_data, outfile)
#  print('XCLOUD JSON OK')




driver.close()









