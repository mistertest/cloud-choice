#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re

from deepdiff import DeepDiff
# from jsondiff import diff



jsondata1 = {"game1": "Steam","game2": "Steam","game3": "Steam","game4": "Steam"}
jsondata2 = {"game1": "Steam, Origin","game2": "Steam","game3": "Steam, Epic","game4": "Steam","game5": "Steam, Ubisfot","game6": "Origin"}


result = DeepDiff(jsondata1,jsondata2)

# result = diff(jsondata1,jsondata2)


result = result['values_changed']


pprint(result)





