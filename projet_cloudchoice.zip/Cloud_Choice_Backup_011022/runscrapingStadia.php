<?php


/* Scrapping Stadia - Mistertest */




/* get json stadia store */
$output1 = shell_exec("scrape-it -c /var/www/html/configStadia.json -u https://stadia.google.com/games > /var/www/html/stadia.json;sed -i 's/&#xAE;/ /g' /var/www/html/stadia.json;sed -i 's/: / /g' /var/www/html/stadia.json");


/* get json stadia pro */
$output2 = shell_exec("scrape-it -c /var/www/html/configStadiapro.json -u https://stadia.google.com/games > /var/www/html/stadiapro.json;sed -i 's/&#xAE;/ /g' /var/www/html/stadiapro.json;sed -i 's/: / /g' /var/www/html/stadiapro.json");




/*message confirmation scrapping ok*/

echo "<b> Scrapping Stadia - OK</b>";


?>