import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json
import unidecode
import re
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# SELENIUM + CHROME HEADLESS DRIVER
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)

# Get Url Games list BlackNut Action
url = 'https://www.blacknut.com/fr/games/cec147bc-c0e1-4b19-8978-75ebd9097224_action'
driver.get(url)
print('BLACKNUT URL OK')

# Wait for the page to load
driver.implicitly_wait(10)

# Scroll down to load all games
scroll_pause_time = 1
screen_height = driver.execute_script("return window.screen.height;")
i = 1
while True:
    driver.execute_script("window.scrollTo(0, {screen_height}*{i});".format(screen_height=screen_height, i=i))
    i += 1
    time.sleep(scroll_pause_time)
    scroll_height = driver.execute_script("return document.body.scrollHeight;")
    if (screen_height) * i > scroll_height:
        break

# Extract game titles and images
game_data = []
img_selectors = driver.find_elements(By.CSS_SELECTOR, 'ul.grid.large-content li img.object-cover')
for img in img_selectors:
    game_title = img.get_attribute('alt')
    game_title = game_title.replace('®','').replace('™','').replace(':','').replace('"', '')
    game_image = img.get_attribute('src')
    game_data.append({"title": game_title, "image_url": game_image})

# Export data to JSON file
with open('blacknut_games.json', 'w') as outfile:
    json.dump(game_data, outfile)

# Close the browser
driver.quit()

print('SCRAPING BLACKNUT GAMES COMPLETED SUCCESSFULLY')
