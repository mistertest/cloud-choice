<?php


/* Scraping PSNOW - Mistertest */



# get json Psnow
$output1 = shell_exec("python3 /var/www/html/psnowSoup.py");



/*message confirmation scrapping ok*/

echo "<b> Scraping PSNOW - OK </b>";


?>