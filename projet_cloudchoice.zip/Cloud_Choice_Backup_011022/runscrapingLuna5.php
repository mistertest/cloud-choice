<?php


/* Scrapping Luna5 */



# get json Luna
 $output1 = shell_exec("python3 /var/www/html/lunaSoup5.py");





/*message confirmation scrapping ok*/

echo "<b> Scrapping Luna5 - OK</b>";


?>