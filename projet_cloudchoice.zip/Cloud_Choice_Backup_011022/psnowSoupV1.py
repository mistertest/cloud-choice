#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re




# SCRAPING PSNOW OK
##################################


# Headless Chrome and Selenium 

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)


# Get The URL to Scrape
driver.get('https://www.playstation.com/fr-fr/ps-now/ps-now-games')


# Confirmation get url
print('SITE PSNOW OK')



# SCRAPING START

my_data = []
my_dataError = [{"title": "error", "store": "error" }]

# Introduction Beautiful Script
soup=BeautifulSoup(driver.page_source,'html.parser')
# print(soup.prettify())


# Code error no data  
if soup.find_all("div", {"class": "box"}):
    print("class Found ok") 
else:
    print("Error not Found class")
    with open('psnowSoup.json', 'w') as outfile:
        json.dump(my_dataError, outfile)
        print('PSNOW JSON WARNING ERROR OK')




# Loop Item div
for p in soup.select('div.tabbed-component div.content-grid div.box p'):
    # print(p.get_text(strip=True, separator='\n'))
    # print('-' * 80)


# Get title of games
    title =  p.get_text(strip=True)
    # Method replace
    # replace(u'\xa0', u' ')
    # Use method unidecode or replace for Unicode Characters
    title = unidecode.unidecode(title)
    # Delete Coyright
    title = title.replace( '*','').replace(':','')

    # Remove word between parenthes in title after create store
    title = re.sub(r"\([^()]*\)","", title)

    itemGame = title
    if len(itemGame) == 0 :
        title = "N/A"
    else:
        title



    if  ( (title == "A") or (title == "B") or (title == "C") or (title == "D") or (title == "E") or (title == "F") 
    or (title == "G") or (title == "H") or (title == "I") or (title == "J") or (title == "K") or (title == "L") 
    or (title == "M") or (title == "N") or (title == "O") or (title == "P") or (title == "Q") or (title == "R") 
    or (title == "S") or (title == "T") or (title == "U") or (title == "V") or (title == "W") or (title == "X")
    or (title == "Y") or (title == "Z") or (title == "0-9")) :
       title = "N/A"






    my_data.append({"title":title })



# Print in Terminal   

    # pprint(my_data)



# CREATE AND EXPORT TO JSON

with open('psnowSoup.json', 'w') as outfile:
     json.dump(my_data, outfile)


     print('PSNOW JSON OK')




# END SCRAPING
####################





driver.close()