<?php


/* Scrapping CRON - Cloudchoice 2022 - Mistertest */


/* get json xbox */
/*$output1 = shell_exec("scrape-it -c /var/www/html/configXbox.json -u https://www.xbox.com/en-us/play/gallery/all-games > /var/www/html/xbox.json;sed -i 's/: / /g' /var/www/html/xbox.json;sed -i 's/&#xAE;//g' /var/www/html/xbox.json;sed -i 's/&#x2122;//g' /var/www/html/xbox.json");*/


/* get json stadia store */
$output2 = shell_exec("scrape-it -c /var/www/html/configStadia.json -u https://stadia.google.com/games > /var/www/html/stadia.json;sed -i 's/&#xAE;/ /g' /var/www/html/stadia.json;sed -i 's/: / /g' /var/www/html/stadia.json");


/* get json stadia pro */
$output3 = shell_exec("scrape-it -c /var/www/html/configStadiapro.json -u https://stadia.google.com/games > /var/www/html/stadiapro.json;sed -i 's/&#xAE;/ /g' /var/www/html/stadiapro.json;sed -i 's/: / /g' /var/www/html/stadiapro.json");


/* get json GFN */

/*$output4 = shell_exec("wget https://static.nvidiagrid.net/supported-public-game-list/locales/gfnpc-en-US.json -O /var/www/html/geforcenow.json;sed -i 's/® / /g' /var/www/html/geforcenow.json;sed -i 's/®//g' /var/www/html/geforcenow.json;sed -i 's/: / /g' /var/www/html/geforcenow.json;sed -i 's/™//g' /var/www/html/geforcenow.json");*/



# get json GFN
$output4 = shell_exec("python3 /var/www/html/gfnSoup.py");

# get json Boosteroid
$output5 = shell_exec("python3 /var/www/html/boosteroidSoup.py");
$output6 = shell_exec("python3 /var/www/html/boosteroidSoup2.py");

# get json Psnow
$output7 = shell_exec("python3 /var/www/html/psnowSoup.py");


# get json Luna
// $output8 = shell_exec("python3 /var/www/html/lunaSoup1.py");
// $output9 = shell_exec("python3 /var/www/html/lunaSoup2.py");
// $output10 = shell_exec("python3 /var/www/html/lunaSoup3.py");
// $output11 = shell_exec("python3 /var/www/html/lunaSoup4.py");
// $output12 = shell_exec("python3 /var/www/html/lunaSoup5.py");
// $output13 = shell_exec("python3 /var/www/html/lunaSoup6.py");

# get json Xcloud
// $output14 = shell_exec("python3 /var/www/html/xcloudSoup.py");



/*message confirmation scrapping ok*/

echo "<b>Scrapping CloudChoice: GFN/Stadia/Boosteroid/Luna/Xcloud/Psnow - OK</b>";


?>