<?php


/* Scrapping Luna2 */



# get json Luna
 $output1 = shell_exec("python3 /var/www/html/lunaSoup2.py");





/*message confirmation scrapping ok*/

echo "<b> Scrapping Luna2 - OK</b>";


?>