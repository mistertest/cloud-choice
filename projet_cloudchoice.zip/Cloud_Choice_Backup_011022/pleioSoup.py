#!/usr/bin/python3
# -*- coding: utf-8 -*-

# IMPORTS - ALL BEAUTIFUL SOUP / SELENIUM / JSON
######################################################

import requests
from bs4 import BeautifulSoup
from pprint import pprint
import json

# For decode Unicode characters
import unidecode
# Search regex
import re



from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import time
from time import sleep
from selenium.common.exceptions import NoSuchElementException

# SELENIUM + CHROME HEADLESS DRIVER
###################################################################

chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
# driver = webdriver.Chrome('/usr/lib/chromium-browser/chromedriver', options=chrome_options)
driver = webdriver.Chrome('/usr/bin/chromedriver', options=chrome_options)



# Get Url Games list Pleio
driver.get('https://www.pleio.games/catalog')
# Confirmation get url
print('PLEIO URL OK')


time.sleep(5) 

# getting the button by class name
button = driver.find_element(By.CLASS_NAME, "CatalogDisplayModeSwitcher-listButton")
 
# Clicking on the button
button.click()
time.sleep(5) 

print('BUTTON CLICK CATALOG OK')
time.sleep(5)




# SCRAPING START
################################

my_data = []
my_dataError = [{"title": "error", "store": "error" }]


# Introduction beautifulsoup
soupx = BeautifulSoup(driver.page_source,'html.parser')
# print(soup.prettify())




# Code error no data  
if soupx.find_all("li", {"class": "CatalogList-item"}):
    print("class Found ok") 
else:
    print("Error not Found class")
    # with open('xcloudSoup.json', 'w') as outfile:
    #     json.dump(my_dataError, outfile)
    #     print('XCLOUD JSON WARNING ERROR OK')

items = soupx.select('li.CatalogList-item') 

for itemGame in items:
    # get title game word
    title = itemGame.select('a.CatalogList-link')[0].get_text()
    
    # Remove word between parenthes in title after create store
    title = re.sub(r"\([^()]*\)","",title)

    # remove last space in title - lstrip for first space
    title = title.rstrip()
    
    # remove leading/trailing whitespace and newline characters
    title = title.strip()
    
    title = unidecode.unidecode(title)

    my_data.append({"title": title})
    pprint(my_data)



with open('pleioSoup.json', 'w') as outfile:
    json.dump(my_data, outfile)
    print('PLEIO SCRAPING FULL OK')

    driver.close()
