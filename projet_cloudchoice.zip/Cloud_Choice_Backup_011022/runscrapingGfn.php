<?php


/* Scrapping GFN */




# get json GFN
$output1 = shell_exec("python3 /var/www/html/gfnSoup.py");




/*message confirmation scrapping ok*/

echo "<b> Scrapping GFN - OK </b>";


?>