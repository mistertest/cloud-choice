<?php


/* Scrapping Luna4 */



# get json Luna
 $output1 = shell_exec("python3 /var/www/html/lunaSoup4.py");





/*message confirmation scrapping ok*/

echo "<b> Scrapping Luna4 - OK</b>";


?>